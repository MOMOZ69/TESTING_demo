# include <stdio.h>
int main() {
  int a,b;
  printf("enter a :");
  scanf("%d",&a);

  printf("enter the value of b :");
  scanf("%d",&b);

  printf("sum is : %d",a +b);

  return 0;
}
